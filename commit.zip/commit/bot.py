from config import getApi
import time
import os
print()



api = getApi(os.environ['consumer_key'], os.environ['consumer_secret'], os.environ['access_token_key'], os.environ['access_token_secret'])
tweets = 0
searchs = 0
limitTweets = 300
limitSearch = 180






def postStatus(update, inReplyTo, media):
    global tweets 
    tweets += 1
    api.PostUpdate(update, media=media, in_reply_to_status_id=inReplyTo)
    


def search(research, howMany):
    global searchs 
    searchs += 1
    searchResults = api.GetSearch(raw_query="q="+research+"&result_type=recent&count="+howMany)
    for search in searchResults:
        if(search.text, "twich.tv"):
            
            postStatus("@" + search.user.screen_name + " streamer c'est pas un vrai metier", search.id, "gneu.jpg")


def start():
    global searchs 
    global tweets 
    while True:
        search("twich.tv", "100")
        if searchs  >= limitSearch:
            print("limite atteinte des searchs")
            time.sleep(900)
            searchs = 0
        elif tweets >= limitTweets:
            print("limite atteinte des tweets")
            time.slepp(3600)
            tweets = 0
        print("on a tweeté " + str(tweets) + " fois !")
        time.sleep(5)


start()





























































































